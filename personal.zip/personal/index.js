/*App Name5P55570610
App Source7183
User IDBHaRF0TdQns
PasswordSJ1kIiC4ZaH
User Key70a2pFeYS3J1eChtEMigrTrgrNTindZX
Encryption KeyQMgpN1WoUsP4WuUrkl4gjYn6kvK7pVuC
Valid up to1/1/2099 12:00:00 PM

DF14K6P2


--sarang below
App Name
5P54556159
App Source
7158
User ID
k3VyvRYUMqa
Password
NFh3pNiUBRx
User Key
3yuBWUZr0ZOYcp5b1ILYyzsz3S0GyBAA
Encryption Key
8a7y0a1AXbXb87TAeyJvneWKHY7ehK34
Valid up to
1/1/2099 12:00:00 PM
*/
// Configuration for your app

let csvfile=`EICHERMOT,910
ACC,22
ADANIPORTS,15083
AXISBANK,5900
`;
let conf = {
    "appSource": "7183",
    "appName": "5P55570610",
    "userId": "IDBHaRF0TdQns",
    "password": "SJ1kIiC4ZaH",
    "userKey": "70a2pFeYS3J1eChtEMigrTrgrNTindZX",
    "encryptionKey": "QMgpN1WoUsP4WuUrkl4gjYn6kvK7pVuC"
}
 conf = {
    "appSource": "7158",
    "appName": "5P54556159",
    "userId": "k3VyvRYUMqa",
    "password": "NFh3pNiUBRx",
    "userKey": "3yuBWUZr0ZOYcp5b1ILYyzsz3S0GyBAA",
    "encryptionKey": "8a7y0a1AXbXb87TAeyJvneWKHY7ehK34"
}

const { FivePaisaClient } = require("5paisajs")

let tableInsertData=[];
let validNamesSet=new Set();
let scripCodeMap=new Map();


let scripNameMap=new Map();

csvfile.split("\n").forEach(itm=>{
    if(!itm)
        return;
    let temparr= itm.split(",");
   scripCodeMap.set(temparr[0],temparr[1]);
   scripNameMap.set(temparr[1],temparr[0]);
})

let validNames='ACC,ADANIENT,ADANIPORTS,AMBUJACEM,APOLLOTYRE,ASHOKLEY,ASIANPAINT,AUROPHARMA,AXISBANK,BAJAJFINSV,BAJFINANCE,BANDHANBNK,BANKBARODA,BHARATFORG,BHARTIARTL,BHEL,BOSCHLTD,BPCL,BRITANNIA,CANBK,CIPLA,COALINDIA,DLF,DRREDDY,EICHERMOT,ESCORTS,FEDERALBNK,GAIL,GOLDBEES,GRASIM,HCLTECH,HDFC,HDFCBANK,HDFCLIFE,HEROMOTOCO,HINDALCO,HINDPETRO,HINDUNILVR,IBULHSGFIN,ICICIBANK,IDEA,INDIAVIX,INDIGO,INDUSINDBK,INDUSTOWER,INFY,IOC,ITC,JINDALSTEL,JSWSTEEL,JUBLFOOD,KOTAKBANK,LICHSGFIN,LT,LUPIN,M&M,M&MFIN,MARUTI,MFSL,MUTHOOTFIN,NESTLEIND,NIFTY,NMDC,NTPC,ONGC,PEL,PFC,PNB,POWERGRID,RBLBANK,RECLTD,RELIANCE,SAIL,SBIN,SHREECEM,SIEMENS,SRTRANSFIN,SUNPHARMA,SUNTV,TATACONSUM,TATAMOTORS,TATAPOWER,TATASTEEL,TCS,TECHM,TITAN,ULTRACEMCO,UPL,VEDL,VOLTAS,WIPRO,ZEEL';
validNames.split(",").forEach(itm=>validNamesSet.add(itm)); 


var client = new FivePaisaClient(conf)
console.log("asfasdf");


//let a=client.historicalData('n', 'c', '1660', '1m','2021-05-31', '2021-06-01')
// This client object can be used to login multiple users.
//QQZzRuFIOzMwajv0VYYigwZ7WsBhf7W3eqdINBCK0CM=
//client.login("amritpk@gmail.com", "DF14K6P2", "19911111").then((response) => {

   client.login("amritpk@gmail.com", "DF14K6P2", "19911111").then((response) => {
//client.login("G4mEFv/dPVhFIk04aCsr5K5YLDnLGC+c/7pJVRp2v9M=", "Jx1GYfkTqq0rATskle5RWg==", "umKfDPY+tl1+5NbMBF6IIA==").then((response) => {

    console.log(response);
   // CLIENT_CODE = response.data.body.ClientCode;
    client.init(response).then(() => {
        // Fetch holdings, positions or place orders here.
        // Some things to try out are given below.
        console.log(response);
        let requiredStockNames='ACC,ADANIENT,ADANIPORTS,AMBUJACEM,APOLLOTYRE,ASHOKLEY,ASIANPAINT,AUROPHARMA,AXISBANK,BAJAJFINSV,BAJFINANCE,BANDHANBNK,BANKBARODA,BHARATFORG,BHARTIARTL,BHEL,BOSCHLTD,BPCL,BRITANNIA,CANBK,CIPLA,COALINDIA,DLF,DRREDDY,EICHERMOT,ESCORTS,FEDERALBNK,GAIL,GOLDBEES,GRASIM,HCLTECH,HDFC,HDFCBANK,HDFCLIFE,HEROMOTOCO,HINDALCO,HINDPETRO,HINDUNILVR,IBULHSGFIN,ICICIBANK,IDEA,INDIAVIX,INDIGO,INDUSINDBK,INDUSTOWER,INFY,IOC,ITC,JINDALSTEL,JSWSTEEL,JUBLFOOD,KOTAKBANK,LICHSGFIN,LT,LUPIN,M&M,M&MFIN,MARUTI,MFSL,MUTHOOTFIN,NESTLEIND,NIFTY,NMDC,NTPC,ONGC,PEL,PFC,PNB,POWERGRID,RBLBANK,RECLTD,RELIANCE,SAIL,SBIN,SHREECEM,SIEMENS,SRTRANSFIN,SUNPHARMA,SUNTV,TATACONSUM,TATAMOTORS,TATAPOWER,TATASTEEL,TCS,TECHM,TITAN,ULTRACEMCO,UPL,VEDL,VOLTAS,WIPRO,ZEEL'.split(",");
        let requiredStockScrips= requiredStockNames.filter((it)=>scripCodeMap.get(it)).map((it=>scripCodeMap.get(it)));

        console.log(requiredStockScrips);

        function gethistData(requiredStockScrips,index){
            let scripcodeTemp=requiredStockScrips[index];
            if(!scripcodeTemp)
                return; 
                // eichermot     let scripcodeTemp='910';
            client.historicalDataRaw('n', 'c', scripcodeTemp, '1m','2021-08-27', '2021-08-27').then((data,err)=>{
                if(data){
                    console.log(data);
                    data.forEach(item=>{
                        //2021-05-24 00:00:00
                        let date1=item[0].substring(0,10);
                        let time1=item[0].replace("T"," ");
                        tableInsertData.push([scripNameMap.get(scripcodeTemp),item[1],time1,new Date(),new Date(),date1,true]);
                    })
                    gethistData(requiredStockScrips,index+1);
                }
        
                else{
                    setTimeout(()=>gethistData(requiredStockScrips,index),1000);
                    console.log(err);
                }
                   
            })
        }
    
        gethistData(requiredStockScrips,0);

     
    



    

    }).catch((err) =>{
        // Oh no :/
        console.log(err)
    })
    
}).catch((err) =>{
    // Oh no :/
    console.log(err)
})


setTimeout(a=> insertrows(tableInsertData),30000);

function insertrows(rows){
    console.log(rows);
    insertToTable(rows,0,chunk_size);

    function insertToTable(values,beg,end){
        if(beg>rows.length){
            console.log("done");
            return;
        }
        console.log("trying from",beg,"to",end);
       // return new Promise((resolve,reject)=>{
           var mysql      = require('mysql');
           var connection = mysql.createConnection({
             host     : 'localhost',
             user     : 'admin',
             password : '12345678',
             database : 'markets'
           });
             /*
            CREATE TABLE `markets`.`scrapeddata2` (
     `id` INT NOT NULL AUTO_INCREMENT ,
     `stockname` VARCHAR(15) NULL,
     `price` FLOAT NULL,
     `time` DATETIME NULL,
     `cretime` DATETIME NULL,
     `modtime` DATETIME NULL,
     `date` DATE NULL,
     `isvalid` VARCHAR(5) NULL DEFAULT 'TRUE',
     UNIQUE INDEX `id_UNIQUE` (`id` ASC),
     PRIMARY KEY (`id`));
     */
       // insert into scrapeddata (date)  select LEFT(time, 10) from scrapeddata 
       //select distinct LEFT(time, 10) as date1,count(*),stockname from scrapeddata where time like '2020-04-06%' group by date1,stockname ;
           //
       var sql = "INSERT INTO scrapeddata7 (stockname, price, time,cretime,modtime,date,isvalid) VALUES ?";
       connection.connect(function(err) {
           if (err) {
               console.log("err");
           }
           console.log('connected as id ' + connection.threadId);
         });
       connection.query(sql, [values.filter((it,ind)=>ind>=beg&&ind<=end)], function(err) {
           if (err) {
               console.log("error in mysqlqqq",err);
               reject(err);
           }
           
           
       });
       connection.end(err=>{
           if(err){
               console.log(err,"unable to close");
               //reject(err);
           }
          
           console.log("inserted from",beg,"to",end);
           insertToTable(rows,end+1,end+chunk_size);
       });
      //  });
     
       }


}